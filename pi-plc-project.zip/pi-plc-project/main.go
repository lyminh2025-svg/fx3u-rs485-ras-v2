package main

import (
	"database/sql"
	"fmt"
	"log"
	"net/http"
	"os"
	"sync"
	"time"

	_ "github.com/go-sql-driver/mysql"
	"github.com/goburrow/modbus"
	"github.com/gorilla/websocket"
)

type PLCData struct {
	Timestamp time.Time `json:"timestamp"`
	Y0Status  bool      `json:"y0_status"`
	D0Value   uint16    `json:"d0_value"`
}

var (
	modbusClient modbus.Client
	db           *sql.DB
	currentData  PLCData
	dataMutex    sync.RWMutex
	upgrader     = websocket.Upgrader{
		CheckOrigin: func(r *http.Request) bool { return true },
	}
)

func main() {
	// Mặc định kết nối DB local trên PC
	dbHost := os.Getenv("DB_HOST")
	if dbHost == "" {
		dbHost = "127.0.0.1"
	}

	// Mặc định cổng Serial trên PC
	serialPort := os.Getenv("SERIAL_PORT")
	if serialPort == "" {
		serialPort = "/dev/ttyUSB0"
	}

	initDB(dbHost)
	defer db.Close()

	initModbus(serialPort)

	go pollPLC()
	go logDataToDB()

	http.Handle("/", http.FileServer(http.Dir("./static")))
	http.HandleFunc("/ws", handleWebSocket)
	http.HandleFunc("/api/toggle-y0", handleToggleY0)

	fmt.Println("🚀 Webserver đang chạy tại: http://localhost:8080")
	log.Fatal(http.ListenAndServe(":8080", nil))
}

func initDB(host string) {
	dsn := fmt.Sprintf("root:123456@tcp(%s:3306)/plc_db?parseTime=true", host)
	var err error

	for i := 0; i < 5; i++ {
		db, err = sql.Open("mysql", dsn)
		if err == nil && db.Ping() == nil {
			break
		}
		log.Println("Đang kết nối MariaDB...")
		time.Sleep(1 * time.Second)
	}

	if err != nil {
		log.Fatalf("Lỗi kết nối MariaDB: %v", err)
	}

	createTable := `
	CREATE TABLE IF NOT EXISTS plc_logs (
		id INT AUTO_INCREMENT PRIMARY KEY,
		timestamp DATETIME,
		y0_status TINYINT(1),
		d0_value INT
	);`
	_, err = db.Exec(createTable)
	if err != nil {
		log.Fatalf("Lỗi tạo bảng: %v", err)
	}
	log.Println("✅ Đã kết nối MariaDB thành công!")
}

func initModbus(port string) {
	handler := modbus.NewRTUClientHandler(port)
	handler.BaudRate = 38400 // Tốc độ BaudRate chuẩn cho FX3U
	handler.DataBits = 8
	handler.Parity = "N"
	handler.StopBits = 1
	handler.SlaveId = 1
	handler.Timeout = 1 * time.Second

	err := handler.Connect()
	if err != nil {
		log.Printf("⚠️ Không mở được cổng Serial (%s): %v", port, err)
	} else {
		log.Printf("✅ Đã kết nối Modbus RTU tới PLC qua cổng (%s)", port)
	}

	modbusClient = modbus.NewClient(handler)
}

func pollPLC() {
	for {
		time.Sleep(300 * time.Millisecond)

		if modbusClient == nil {
			continue
		}

		// Đọc trạng thái Coil Y0
		coils, err := modbusClient.ReadCoils(0, 1)
		y0 := false
		if err == nil && len(coils) > 0 {
			y0 = (coils[0] & 0x01) == 1
		}

		// Đọc giá trị Holding Register D0
		regs, err := modbusClient.ReadHoldingRegisters(0, 1)
		var d0 uint16 = 0
		if err == nil && len(regs) >= 2 {
			d0 = uint16(regs[0])<<8 | uint16(regs[1])
		}

		dataMutex.Lock()
		currentData = PLCData{
			Timestamp: time.Now(),
			Y0Status:  y0,
			D0Value:   d0,
		}
		dataMutex.Unlock()
	}
}

func logDataToDB() {
	ticker := time.NewTicker(5 * time.Second)
	for range ticker.C {
		dataMutex.RLock()
		data := currentData
		dataMutex.RUnlock()

		if db == nil {
			continue
		}

		_, err := db.Exec("INSERT INTO plc_logs (timestamp, y0_status, d0_value) VALUES (?, ?, ?)",
			data.Timestamp, data.Y0Status, data.D0Value)
		if err != nil {
			log.Printf("Lỗi ghi DB: %v", err)
		}
	}
}

func handleWebSocket(w http.ResponseWriter, r *http.Request) {
	conn, err := upgrader.Upgrade(w, r, nil)
	if err != nil {
		return
	}
	defer conn.Close()

	for {
		dataMutex.RLock()
		data := currentData
		dataMutex.RUnlock()

		err := conn.WriteJSON(data)
		if err != nil {
			break
		}
		time.Sleep(500 * time.Millisecond)
	}
}

func handleToggleY0(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	dataMutex.RLock()
	nextState := !currentData.Y0Status
	dataMutex.RUnlock()

	var value uint16 = 0x0000
	if nextState {
		value = 0xFF00
	}

	if modbusClient != nil {
		_, err := modbusClient.WriteSingleCoil(0, value)
		if err != nil {
			http.Error(w, fmt.Sprintf("Lỗi gửi lệnh PLC: %v", err), http.StatusInternalServerError)
			return
		}
	}

	w.WriteHeader(http.StatusOK)
	w.Write([]byte("OK"))
}
