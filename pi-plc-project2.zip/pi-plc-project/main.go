package main

import (
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"sync"
	"time"

	"github.com/goburrow/modbus"
	"github.com/gorilla/websocket"
)

var upgrader = websocket.Upgrader{
	CheckOrigin: func(r *http.Request) bool { return true },
}

type Client struct {
	conn *websocket.Conn
	send chan []byte
}

type Hub struct {
	clients    map[*Client]bool
	broadcast  chan []byte
	register   chan *Client
	unregister chan *Client
	mutex      sync.Mutex
}

var hub = Hub{
	broadcast:  make(chan []byte),
	register:   make(chan *Client),
	unregister: make(chan *Client),
	clients:    make(map[*Client]bool),
}

func (h *Hub) run() {
	for {
		select {
		case client := <-h.register:
			h.mutex.Lock()
			h.clients[client] = true
			h.mutex.Unlock()
		case client := <-h.unregister:
			h.mutex.Lock()
			if _, ok := h.clients[client]; ok {
				delete(h.clients, client)
				close(client.send)
			}
			h.mutex.Unlock()
		case message := <-h.broadcast:
			h.mutex.Lock()
			for client := range h.clients {
				select {
				case client.send <- message:
				default:
					close(client.send)
					delete(h.clients, client)
				}
			}
			h.mutex.Unlock()
		}
	}
}

var mbClient modbus.Client
var mbMutex sync.Mutex

// Hàm đọc dữ liệu định kỳ từ PLC và đẩy qua WebSocket
func pollPLC() {
	for {
		time.Sleep(200 * time.Millisecond)

		mbMutex.Lock()
		// 1. Đọc trạng thái M20, M21 (Coil Address Modbus: M20 -> 20, đọc 2 coils)
		mResults, errM := mbClient.ReadCoils(20, 2)
		
		// 2. Đọc T1, T2, T3 (Timer Current Value)
		tResults, errT := mbClient.ReadHoldingRegisters(1, 3)

		// 3. Đọc D200 - D208
		dResults, errD := mbClient.ReadHoldingRegisters(200, 9)
		mbMutex.Unlock()

		data := make(map[string]interface{})

		// Cấu hình data bits M20, M21
		if errM == nil && len(mResults) > 0 {
			data["bits"] = map[string]bool{
				"M20": (mResults[0] & 0x01) != 0,
				"M21": (mResults[0] & 0x02) != 0,
			}
		}

		// Cấu hình data Timers T
		if errT == nil && len(tResults) >= 6 {
			data["timers"] = map[string]int{
				"T1": int(uint16(tResults[0])<<8 | uint16(tResults[1])),
				"T2": int(uint16(tResults[2])<<8 | uint16(tResults[3])),
				"T3": int(uint16(tResults[4])<<8 | uint16(tResults[5])),
			}
		}

		// Cấu hình data D-Registers
		if errD == nil && len(dResults) >= 18 {
			data["settings"] = map[string]int{
				"D200": int(uint16(dResults[0])<<8 | uint16(dResults[1])),
				"D201": int(uint16(dResults[2])<<8 | uint16(dResults[3])),
				"D202": int(uint16(dResults[4])<<8 | uint16(dResults[5])),
				"D203": int(uint16(dResults[6])<<8 | uint16(dResults[7])),
				"D204": int(uint16(dResults[8])<<8 | uint16(dResults[9])),
				"D206": int(uint16(dResults[12])<<8 | uint16(dResults[13])),
				"D208": int(uint16(dResults[16])<<8 | uint16(dResults[17])),
			}
		}

		if len(data) > 0 {
			jsonBytes, _ := json.Marshal(data)
			hub.broadcast <- jsonBytes
		}
	}
}

func handleWS(w http.ResponseWriter, r *http.Request) {
	conn, err := upgrader.Upgrade(w, r, nil)
	if err != nil {
		log.Println("WS Upgrade Error:", err)
		return
	}
	client := &Client{conn: conn, send: make(chan []byte, 256)}
	hub.register <- client

	go func() {
		defer func() {
			hub.unregister <- client
			conn.Close()
		}()
		for message := range client.send {
			conn.WriteMessage(websocket.TextMessage, message)
		}
	}()
}

type BitPayload struct {
	BitAddress int  `json:"bit_address"`
	State      bool `json:"state"`
}

func handleControlBit(w http.ResponseWriter, r *http.Request) {
	var p BitPayload
	if err := json.NewDecoder(r.Body).Decode(&p); err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	mbMutex.Lock()
	var val uint16 = 0x0000
	if p.State {
		val = 0xFF00
	}
	_, err := mbClient.WriteSingleCoil(uint16(p.BitAddress), val)
	mbMutex.Unlock()

	if err != nil {
		http.Error(w, "Error writing coil", http.StatusInternalServerError)
		return
	}
	w.WriteHeader(http.StatusOK)
}

type SavePayload struct {
	Settings map[uint16]uint16 `json:"settings"`
}

func handleSaveSettings(w http.ResponseWriter, r *http.Request) {
	var p SavePayload
	if err := json.NewDecoder(r.Body).Decode(&p); err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	mbMutex.Lock()
	for addr, val := range p.Settings {
		_, err := mbClient.WriteSingleRegister(addr, val)
		if err != nil {
			mbMutex.Unlock()
			http.Error(w, fmt.Sprintf("Error writing D%d", addr), http.StatusInternalServerError)
			return
		}
	}
	mbMutex.Unlock()

	w.WriteHeader(http.StatusOK)
}

func main() {
	// Kết nối Modbus RTU PLC (Thay /dev/ttyUSB0 nếu khác)
	handler := modbus.NewRTUClientHandler("/dev/ttyUSB0")
	handler.BaudRate = 9600
	handler.DataBits = 8
	handler.Parity = "E"
	handler.StopBits = 1
	handler.SlaveId = 1
	handler.Timeout = 1 * time.Second

	if err := handler.Connect(); err != nil {
		log.Println("⚠️ Không thể nối Modbus PLC, đang chạy Mode Simulation...")
	}
	defer handler.Close()
	mbClient = modbus.NewClient(handler)

	go hub.run()
	go pollPLC()

	http.Handle("/", http.FileServer(http.Dir("./static")))
	http.HandleFunc("/ws", handleWS)
	http.HandleFunc("/api/control-bit", handleControlBit)
	http.HandleFunc("/api/save-settings", handleSaveSettings)

	log.Println("🚀 Web Server đang chạy tại http://localhost:8080")
	log.Fatal(http.ListenAndServe(":8080", nil))
}
